set autocommit = off;

start transaction;

insert into pozemek (cislo) values (1);
insert into pozemek (cislo) values (2);
insert into pozemek (cislo) values (3);
insert into pozemek (cislo) values (4);
insert into pozemek (cislo) values (5);
insert into pozemek (cislo) values (6);
insert into pozemek (cislo) values (7);
insert into pozemek (cislo) values (8);
insert into pozemek (cislo) values (9);
insert into pozemek (cislo) values (10);
insert into pozemek (cislo) values (11);
insert into pozemek (cislo) values (12);
insert into pozemek (cislo) values (13);
insert into pozemek (cislo) values (14);
insert into pozemek (cislo) values (15);
insert into pozemek (cislo) values (16);
insert into pozemek (cislo) values (17);
insert into pozemek (cislo) values (18);
insert into pozemek (cislo) values (19);
insert into pozemek (cislo) values (20);
insert into pozemek (cislo) values (21);
insert into pozemek (cislo) values (22);
insert into pozemek (cislo) values (23);
insert into pozemek (cislo) values (24);
insert into pozemek (cislo) values (25);
insert into pozemek (cislo) values (26);
insert into pozemek (cislo) values (27);
insert into pozemek (cislo) values (28);
insert into pozemek (cislo) values (29);
insert into pozemek (cislo) values (30);


commit;