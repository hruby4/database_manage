set autocommit = off;

start transaction;

insert into sousedstvi (id_pozemek, id_misto_prace) values (11, 12);
insert into sousedstvi (id_pozemek, id_misto_prace) values (22, 29);
insert into sousedstvi (id_pozemek, id_misto_prace) values (17, 11);
insert into sousedstvi (id_pozemek, id_misto_prace) values (16, 25);
insert into sousedstvi (id_pozemek, id_misto_prace) values (4, 13);
insert into sousedstvi (id_pozemek, id_misto_prace) values (12, 22);
insert into sousedstvi (id_pozemek, id_misto_prace) values (18, 8);
insert into sousedstvi (id_pozemek, id_misto_prace) values (1, 29);
insert into sousedstvi (id_pozemek, id_misto_prace) values (24, 3);
insert into sousedstvi (id_pozemek, id_misto_prace) values (7, 9);
insert into sousedstvi (id_pozemek, id_misto_prace) values (29, 28);
insert into sousedstvi (id_pozemek, id_misto_prace) values (1, 17);
insert into sousedstvi (id_pozemek, id_misto_prace) values (24, 29);
insert into sousedstvi (id_pozemek, id_misto_prace) values (7, 9);
insert into sousedstvi (id_pozemek, id_misto_prace) values (16, 15);
insert into sousedstvi (id_pozemek, id_misto_prace) values (10, 16);
insert into sousedstvi (id_pozemek, id_misto_prace) values (13, 22);
insert into sousedstvi (id_pozemek, id_misto_prace) values (10, 15);
insert into sousedstvi (id_pozemek, id_misto_prace) values (2, 22);
insert into sousedstvi (id_pozemek, id_misto_prace) values (9, 6);
insert into sousedstvi (id_pozemek, id_misto_prace) values (26, 30);
insert into sousedstvi (id_pozemek, id_misto_prace) values (29, 29);
insert into sousedstvi (id_pozemek, id_misto_prace) values (15, 16);
insert into sousedstvi (id_pozemek, id_misto_prace) values (4, 12);
insert into sousedstvi (id_pozemek, id_misto_prace) values (25, 3);
insert into sousedstvi (id_pozemek, id_misto_prace) values (16, 9);
insert into sousedstvi (id_pozemek, id_misto_prace) values (4, 28);
insert into sousedstvi (id_pozemek, id_misto_prace) values (14, 19);
insert into sousedstvi (id_pozemek, id_misto_prace) values (6, 6);
insert into sousedstvi (id_pozemek, id_misto_prace) values (11, 1);




commit;