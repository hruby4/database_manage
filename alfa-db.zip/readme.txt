potřebujete:
lokalni databazovy server v MySQL a do neho 
python min. verzi 3.x


návod:
nahrajte export databaze do databazoveho serveru
nastavte config.conf pro pripojeni k databazi 	- host = adresa databaze
						- user = username k pripojeni k databazi
						- password = heslo k pripojeni k databazi
						- databaze = vyber schematu k pripojeni
spustte program v pythonu
