from src import ui


if __name__ == '__main__':
    ui.start()






